let rootNode = document.getElementById("root");

// Your code goes here
